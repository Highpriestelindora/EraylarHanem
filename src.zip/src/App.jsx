import React from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { Toaster } from 'react-hot-toast';
import AppLayout from './components/AppLayout';
import Home from './pages/Home';
import Mutfak from './pages/Mutfak';
import Kasa from './pages/Kasa';
import Saglik from './pages/Saglik';
import Ayarlar from './pages/Ayarlar';

// Additional Modules
import Sosyal from './pages/Sosyal';
import Hedefler from './pages/Hedefler';
import Ev from './pages/Ev';
import Pet from './pages/Pet';
import Aracim from './pages/Aracim';
import Tatil from './pages/Tatil';

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Home />} />
          <Route path="mutfak" element={<Mutfak />} />
          <Route path="kasa" element={<Kasa />} />
          <Route path="saglik" element={<Saglik />} />
          <Route path="ayarlar" element={<Ayarlar />} />
          
          {/* Ek Modüller */}
          <Route path="sosyal" element={<Sosyal />} />
          <Route path="hedefler" element={<Hedefler />} />
          <Route path="ev" element={<Ev />} />
          <Route path="pet" element={<Pet />} />
          <Route path="aracim" element={<Aracim />} />
          <Route path="tatil" element={<Tatil />} />
        </Route>
      </Routes>
    </AnimatePresence>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Toaster 
        position="top-center"
        toastOptions={{
          style: {
            borderRadius: '14px',
            background: 'var(--card)',
            color: 'var(--txt)',
            border: '1px solid var(--brd)',
            boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
            padding: '12px 20px',
            fontSize: '14px',
            fontWeight: 600,
          },
        }}
      />
      <AnimatedRoutes />
    </BrowserRouter>
  );
}

export default App;
