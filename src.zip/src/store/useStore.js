import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '../lib/supabaseClient';

const useStore = create(
  persist(
    (set, get) => ({
      // State definitions
      user: null,
      menu: {},           // M
      fridge: [],         // F
      pantry: [],         // P
      freezer: [],        // DON
      recipes: [],        // R
      wallet: null,       // KASA
      expenses: [],       // GIDER
      pets: null,         // PET
      car: { km: 47230 }, // C
      water: {},          // D

      // Actions
      setUser: (user) => set({ user }),
      
      // Generic update for module data
      updateModuleData: (moduleKey, data) => set((state) => ({ [moduleKey]: data })),

      // Supabase Sync Action
      syncWithSupabase: async () => {
        const state = get();
        try {
          // This simulates the sync() function from core.js
          // Example: Push current state to Supabase
          const { error } = await supabase
            .from('eraylar_store')
            .upsert({ id: 1, data: state });

          if (error) {
            console.error('Supabase Sync Error:', error);
          }
        } catch (err) {
          console.error('Network Error during sync', err);
        }
      }
    }),
    {
      name: 'eraylar-react-state', // unique name for localStorage key
      partialize: (state) => ({
        user: state.user,
        menu: state.menu,
        fridge: state.fridge,
        pantry: state.pantry,
        freezer: state.freezer,
        recipes: state.recipes,
        wallet: state.wallet,
        expenses: state.expenses,
        pets: state.pets,
        car: state.car,
        water: state.water
      }),
    }
  )
);

export default useStore;
