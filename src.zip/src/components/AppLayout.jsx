import React from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { Home, Utensils, HeartPulse, Wallet, Settings } from 'lucide-react';
import './AppLayout.css';

export default function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: '/', icon: Home, label: 'Ev' },
    { path: '/mutfak', icon: Utensils, label: 'Mutfak' },
    { path: '/kasa', icon: Wallet, label: 'Kasa' },
    { path: '/saglik', icon: HeartPulse, label: 'Sağlık' },
    { path: '/ayarlar', icon: Settings, label: 'Ayar' }
  ];

  return (
    <div className="app-container">
      {/* Header */}
      <header className="app-header glass">
        <div>
          <h1>Eraylar Hanem</h1>
          <small>Hoş geldin, Görkem</small>
        </div>
        <div className="header-actions">
          <div className="avatar">G</div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="app-content">
        <Outlet />
      </main>

      {/* Bottom Navigation */}
      <nav className="app-nav glass">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
          return (
            <button
              key={item.path}
              className={`nav-btn ${isActive ? 'active' : ''}`}
              onClick={() => navigate(item.path)}
            >
              <item.icon size={22} className="nav-icon" />
              <span className="nav-label">{item.label}</span>
              {isActive && <div className="nav-dot" />}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
