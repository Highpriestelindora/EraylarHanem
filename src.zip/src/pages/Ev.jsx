import React from 'react';
import { Home as HomeIcon, Plus } from 'lucide-react';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './GenericModule.css';

export default function Ev() {
  return (
    <AnimatedPage className="generic-container ev-theme">
      <div className="generic-header">
        <h2>Eraylar Ev</h2>
        <p>Faturalar ve ev düzeni</p>
      </div>

      <div className="generic-content">
        <div className="empty-state">
          <HomeIcon size={48} className="empty-icon" />
          <p>Kayıtlı görev veya fatura yok</p>
        </div>
        <button className="btn-action" onClick={() => toast.success('Ev modülü işlem penceresi açılıyor...')}>
          <Plus size={18} /> Yeni Kayıt Ekle
        </button>
      </div>
    </AnimatedPage>
  );
}
