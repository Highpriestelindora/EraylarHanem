import React from 'react';
import { Car, Plus } from 'lucide-react';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './GenericModule.css';

export default function Aracim() {
  return (
    <AnimatedPage className="generic-container aracim-theme">
      <div className="generic-header">
        <h2>Eraylar Aracım</h2>
        <p>Bakım, yakıt ve kilometre takibi</p>
      </div>

      <div className="generic-content">
        <div className="empty-state">
          <Car size={48} className="empty-icon" />
          <p>Kayıtlı araç bilgisi yok</p>
        </div>
        <button className="btn-action" onClick={() => toast.success('Araç işlem penceresi açılıyor...')}>
          <Plus size={18} /> Yeni Araç / Bakım Ekle
        </button>
      </div>
    </AnimatedPage>
  );
}
