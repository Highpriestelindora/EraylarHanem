import React, { useState } from 'react';
import { CalendarDays, ShoppingBag, Refrigerator, ChefHat } from 'lucide-react';
import AnimatedPage from '../components/AnimatedPage';
import useStore from '../store/useStore';
import './Mutfak.css';

export default function Mutfak() {
  const [activeTab, setActiveTab] = useState('menu');
  const { menu, recipes } = useStore();

  const tabs = [
    { id: 'menu', label: 'Haftalık Menü', icon: CalendarDays },
    { id: 'stok', label: 'Buzdolabı', icon: Refrigerator },
    { id: 'alisveris', label: 'Alışveriş', icon: ShoppingBag },
    { id: 'tarifler', label: 'Tarifler', icon: ChefHat },
  ];

  return (
    <AnimatedPage className="mutfak-container">
      {/* Header Area */}
      <div className="mutfak-header">
        <h2>Mutfak Yönetimi</h2>
        <p>Ne pişirsek, ne alsak?</p>
      </div>

      {/* Tabs */}
      <div className="mutfak-tabs-wrapper">
        <div className="mutfak-tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <tab.icon size={18} />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="mutfak-content-area">
        {activeTab === 'menu' && <MenuTab menuData={menu} />}
        {activeTab === 'stok' && <div className="placeholder">Stok Modülü Yapım Aşamasında</div>}
        {activeTab === 'alisveris' && <div className="placeholder">Alışveriş Listesi Yapım Aşamasında</div>}
        {activeTab === 'tarifler' && <div className="placeholder">Tarifler Yapım Aşamasında</div>}
      </div>
    </AnimatedPage>
  );
}

import toast from 'react-hot-toast';

// Internal Component for the Menu Tab
function MenuTab({ menuData }) {
  // Generate days for the week
  const days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
  
  return (
    <div className="menu-tab">
      <div className="menu-actions">
        <button className="btn-primary" onClick={() => toast.success('Otomatik menü başarıyla oluşturuldu!')}>
          <ChefHat size={16} /> Otomatik Menü Oluştur
        </button>
      </div>
      
      <div className="days-list">
        {days.map((day, idx) => {
          // Dummy data for visual
          const hasFood = idx === 0 || idx === 1;
          return (
            <div key={day} className={`day-card ${hasFood ? 'filled' : 'empty'}`}>
              <div className="day-header">
                <span className="day-name">{day}</span>
              </div>
              <div className="day-body">
                {hasFood ? (
                  <div className="meal-item">
                    <span className="meal-icon">🥘</span>
                    <div className="meal-info">
                      <h4>{idx === 0 ? 'Fırın Tavuk & Patates' : 'Kremalı Makarna'}</h4>
                      <span>Akşam Yemeği</span>
                    </div>
                  </div>
                ) : (
                  <button className="add-meal-btn">
                    + Yemek Ekle
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
