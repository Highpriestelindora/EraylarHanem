import React from 'react';
import { PawPrint, Plus } from 'lucide-react';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './GenericModule.css';

export default function Pet() {
  return (
    <AnimatedPage className="generic-container pet-theme">
      <div className="generic-header">
        <h2>Eraylar Pet</h2>
        <p>Aşılar, beslenme ve bakımlar</p>
      </div>

      <div className="generic-content">
        <div className="empty-state">
          <PawPrint size={48} className="empty-icon" />
          <p>Kayıtlı evcil hayvan bilgisi yok</p>
        </div>
        <button className="btn-action" onClick={() => toast.success('Pet modülü işlem penceresi açılıyor...')}>
          <Plus size={18} /> Yeni Pet Kaydı Ekle
        </button>
      </div>
    </AnimatedPage>
  );
}
