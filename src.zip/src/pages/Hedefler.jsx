import React from 'react';
import { Target, Plus } from 'lucide-react';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './GenericModule.css';

export default function Hedefler() {
  return (
    <AnimatedPage className="generic-container hedefler-theme">
      <div className="generic-header">
        <h2>Eraylar Hedefler</h2>
        <p>Birlikte başarılanlar</p>
      </div>

      <div className="generic-content">
        <div className="empty-state">
          <Target size={48} className="empty-icon" />
          <p>Henüz hedef eklenmedi</p>
        </div>
        <button className="btn-action" onClick={() => toast.success('Yeni hedef ekleme açılıyor...')}>
          <Plus size={18} /> Yeni Hedef Ekle
        </button>
      </div>
    </AnimatedPage>
  );
}
