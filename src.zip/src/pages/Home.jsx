import React from 'react';
import { Calendar, Wallet, CheckCircle, Utensils, Users, Target, Home as HomeIcon, PawPrint, Car, Map, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import AnimatedPage from '../components/AnimatedPage';
import './Home.css';

export default function Home() {
  return (
    <AnimatedPage className="home-container">
      {/* Date Banner */}
      <div className="date-banner">
        <h2>{new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' })}</h2>
        <p>Günün özeti ve planların</p>
      </div>

      {/* Quick Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper wallet">
            <Wallet size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-label">Bakiye</span>
            <span className="stat-value">₺12,450</span>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon-wrapper food">
            <Utensils size={20} />
          </div>
          <div className="stat-info">
            <span className="stat-label">Akşam Yemeği</span>
            <span className="stat-value text-sm">Fırın Tavuk</span>
          </div>
        </div>
      </div>

      {/* All Modules Grid */}
      <div className="section-header" style={{marginTop: '10px'}}>
        <h3>Modüller</h3>
      </div>

      <div className="modules-grid">
        <Link to="/sosyal" className="module-grid-item" style={{'--mc': '#E91E63'}}>
          <div className="mg-icon"><Users size={20} /></div>
          <span>Sosyal</span>
        </Link>
        <Link to="/hedefler" className="module-grid-item" style={{'--mc': '#8B5CF6'}}>
          <div className="mg-icon"><Target size={20} /></div>
          <span>Hedefler</span>
        </Link>
        <Link to="/ev" className="module-grid-item" style={{'--mc': '#F59E0B'}}>
          <div className="mg-icon"><HomeIcon size={20} /></div>
          <span>Ev</span>
        </Link>
        <Link to="/pet" className="module-grid-item" style={{'--mc': '#06B6D4'}}>
          <div className="mg-icon"><PawPrint size={20} /></div>
          <span>Pet</span>
        </Link>
        <Link to="/aracim" className="module-grid-item" style={{'--mc': '#64748B'}}>
          <div className="mg-icon"><Car size={20} /></div>
          <span>Aracım</span>
        </Link>
        <Link to="/tatil" className="module-grid-item" style={{'--mc': '#EC4899'}}>
          <div className="mg-icon"><Map size={20} /></div>
          <span>Tatil</span>
        </Link>
      </div>
    </AnimatedPage>
  );
}
