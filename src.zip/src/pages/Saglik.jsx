import React, { useState } from 'react';
import { Calendar, Pill, Activity, Plus } from 'lucide-react';
import useStore from '../store/useStore';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './Saglik.css';

export default function Saglik() {
  const [activeTab, setActiveTab] = useState('randevu');
  const { saglik } = useStore(state => state);

  // Fallback
  const S = saglik || { randevular: [], ilaclar: [], olcumler: [] };

  const tabs = [
    { id: 'randevu', label: 'Randevu', icon: Calendar },
    { id: 'ilac', label: 'İlaç', icon: Pill },
    { id: 'olcum', label: 'Ölçüm', icon: Activity }
  ];

  return (
    <AnimatedPage className="saglik-container">
      {/* Header */}
      <div className="saglik-header">
        <h2>Eraylar Sağlık</h2>
        <p>Randevu · İlaç · Ölçüm</p>
      </div>

      {/* Tabs */}
      <div className="saglik-tabs-wrapper">
        <div className="saglik-tabs">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <tab.icon size={18} />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="saglik-content">
        {activeTab === 'randevu' && (
          <div className="tab-view">
            <div className="empty-state">
              <Calendar size={48} className="empty-icon" />
              <p>Yaklaşan randevu yok</p>
            </div>
            <button className="btn-action" onClick={() => toast.success('Yeni randevu ekleme modülü açılıyor...')}>
              <Plus size={18} /> Yeni Randevu Ekle
            </button>
          </div>
        )}

        {activeTab === 'ilac' && (
          <div className="tab-view">
             <div className="empty-state">
              <Pill size={48} className="empty-icon" />
              <p>Aktif ilaç kullanımı yok</p>
            </div>
            <button className="btn-action" onClick={() => toast.success('Yeni ilaç ekleme modülü açılıyor...')}>
              <Plus size={18} /> Yeni İlaç Ekle
            </button>
          </div>
        )}

        {activeTab === 'olcum' && (
          <div className="tab-view">
             <div className="empty-state">
              <Activity size={48} className="empty-icon" />
              <p>Henüz ölçüm eklenmedi</p>
            </div>
            <button className="btn-action" onClick={() => toast.success('Yeni ölçüm ekleme modülü açılıyor...')}>
              <Plus size={18} /> Yeni Ölçüm Ekle
            </button>
          </div>
        )}
      </div>
    </AnimatedPage>
  );
}
