import React, { useState } from 'react';
import useStore from '../store/useStore';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './Kasa.css';

export default function Kasa() {
  const [activeTab, setActiveTab] = useState('bakiye');
  const { wallet, updateModuleData } = useStore();

  // Fallback state if wallet is null
  const K = wallet || { gorkem: 0, esra: 0, ortak: 0, gecmis: [] };
  const total = (K.gorkem || 0) + (K.esra || 0) + (K.ortak || 0);

  const formatMoney = (val) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <AnimatedPage className="kasa-container">
      {/* Header */}
      <div className="kasa-header">
        <h2>Eraylar Kasa</h2>
        <p>Bütçe ve Birikim Takibi</p>
      </div>

      {/* Tabs */}
      <div className="kasa-tabs">
        <button 
          className={`tab-btn ${activeTab === 'bakiye' ? 'active' : ''}`}
          onClick={() => setActiveTab('bakiye')}
        >
          💰 Bakiye
        </button>
        <button 
          className={`tab-btn ${activeTab === 'gecmis' ? 'active' : ''}`}
          onClick={() => setActiveTab('gecmis')}
        >
          📋 Geçmiş
        </button>
      </div>

      <div className="kasa-content">
        {activeTab === 'bakiye' ? (
          <div className="bakiye-view">
            {/* Total Card */}
            <div className="total-card glass">
              <div className="total-label">TOPLAM BİRİKİM</div>
              <div className="total-value">{formatMoney(total)}</div>
            </div>

            {/* Individual Cards */}
            <div className="person-cards">
              <div className="person-card gorkem">
                <div className="person-label">👨 Görkem</div>
                <div className="person-value">{formatMoney(K.gorkem)}</div>
                <button className="btn-update gorkem-btn" onClick={() => toast.success('Görkem bakiyesi güncellendi!')}>Güncelle</button>
              </div>

              <div className="person-card esra">
                <div className="person-label">👩 Esra</div>
                <div className="person-value">{formatMoney(K.esra)}</div>
                <button className="btn-update esra-btn" onClick={() => toast.success('Esra bakiyesi güncellendi!')}>Güncelle</button>
              </div>

              <div className="person-card ortak">
                <div className="person-label">🏡 Ortak</div>
                <div className="person-value">{formatMoney(K.ortak)}</div>
                <button className="btn-update ortak-btn" onClick={() => toast.success('Ortak bakiye güncellendi!')}>Güncelle</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="gecmis-view">
            <div className="gecmis-card">
              <h3>Bakiye Geçmişi</h3>
              {K.gecmis && K.gecmis.length > 0 ? (
                <div className="gecmis-list">
                  {K.gecmis.slice().reverse().map((item, idx) => (
                    <div key={idx} className="gecmis-item">
                      <div className="gecmis-info">
                        <strong>{item.kisi === 'gorkem' ? '👨 Görkem' : item.kisi === 'esra' ? '👩 Esra' : '🏡 Ortak'}</strong>
                        <span>{item.dt} {item.not ? `· ${item.not}` : ''}</span>
                      </div>
                      <div className={`gecmis-amount ${item.fark >= 0 ? 'positive' : 'negative'}`}>
                        {item.fark >= 0 ? '+' : ''}{formatMoney(item.fark)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="placeholder">Henüz kayıt yok</div>
              )}
            </div>
          </div>
        )}
      </div>
    </AnimatedPage>
  );
}
