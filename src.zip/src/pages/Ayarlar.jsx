import React, { useState } from 'react';
import { User, Bell, Shield, Moon, LogOut } from 'lucide-react';
import useStore from '../store/useStore';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './Ayarlar.css';

export default function Ayarlar() {
  const { user, setUser } = useStore();
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
  };

  return (
    <AnimatedPage className="ayarlar-container">
      <div className="ayarlar-header">
        <h2>Ayarlar</h2>
        <p>Uygulama tercihleri ve profil</p>
      </div>

      <div className="profile-card">
        <div className="avatar-large">{user ? user.charAt(0).toUpperCase() : 'G'}</div>
        <div className="profile-info">
          <h3>{user || 'Görkem'}</h3>
          <span>Aile Üyesi</span>
        </div>
        <button className="btn-edit-profile">Düzenle</button>
      </div>

      <div className="settings-group">
        <h4>Genel Ayarlar</h4>
        
        <div className="setting-item">
          <div className="setting-icon"><Moon size={20} /></div>
          <div className="setting-content">
            <span className="setting-title">Karanlık Mod</span>
            <span className="setting-desc">Premium koyu tema</span>
          </div>
          <label className="toggle-switch">
            <input type="checkbox" checked={darkMode} onChange={toggleDarkMode} />
            <span className="slider"></span>
          </label>
        </div>

        <div className="setting-item">
          <div className="setting-icon"><Bell size={20} /></div>
          <div className="setting-content">
            <span className="setting-title">Bildirimler</span>
            <span className="setting-desc">Randevu ve ödeme hatırlatıcıları</span>
          </div>
          <label className="toggle-switch">
            <input type="checkbox" defaultChecked />
            <span className="slider"></span>
          </label>
        </div>
      </div>

      <div className="settings-group">
        <h4>Güvenlik & Hesap</h4>
        
        <div className="setting-item clickable">
          <div className="setting-icon"><Shield size={20} /></div>
          <div className="setting-content">
            <span className="setting-title">Şifre ve Güvenlik</span>
          </div>
          <div className="chevron">›</div>
        </div>
        
        <div className="setting-item clickable text-danger" onClick={() => setUser(null)}>
          <div className="setting-icon"><LogOut size={20} /></div>
          <div className="setting-content">
            <span className="setting-title">Çıkış Yap</span>
          </div>
        </div>
      </div>
      
      <div className="app-version">
        Eraylar Hanem v9.0.0 (React Edition)
      </div>
    </AnimatedPage>
  );
}
