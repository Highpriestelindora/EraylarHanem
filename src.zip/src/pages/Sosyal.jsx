import React, { useState } from 'react';
import { Calendar, Dumbbell, Archive, Lightbulb, Plus } from 'lucide-react';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './Sosyal.css';

export default function Sosyal() {
  const [activeTab, setActiveTab] = useState('hafta');

  const tabs = [
    { id: 'hafta', label: 'Bu Hafta', icon: Calendar },
    { id: 'rutinler', label: 'Rutinler', icon: Dumbbell },
    { id: 'arsiv', label: 'Arşiv', icon: Archive },
    { id: 'havuz', label: 'Havuz', icon: Lightbulb }
  ];

  return (
    <AnimatedPage className="sosyal-container">
      <div className="sosyal-header">
        <h2>Eraylar Sosyal</h2>
        <p>Aktivite & Rutin & Havuz</p>
      </div>

      <div className="sosyal-tabs-wrapper">
        <div className="sosyal-tabs">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <tab.icon size={18} />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="sosyal-content">
        {activeTab === 'hafta' && (
          <div className="tab-view">
             <div className="empty-state">
              <Calendar size={48} className="empty-icon" />
              <p>Bu hafta için plan yok!</p>
            </div>
            <button className="btn-action" onClick={() => toast.success('Yeni aktivite ekleme açılıyor...')}>
              <Plus size={18} /> Aktivite Planla
            </button>
          </div>
        )}

        {activeTab === 'rutinler' && (
          <div className="tab-view">
             <div className="empty-state">
              <Dumbbell size={48} className="empty-icon" />
              <p>Henüz rutin eklenmedi</p>
            </div>
            <button className="btn-action" onClick={() => toast.success('Rutin ekleme açılıyor...')}>
              <Plus size={18} /> Rutin Ekle
            </button>
          </div>
        )}
        
        {activeTab === 'arsiv' && (
          <div className="tab-view">
            <div className="empty-state">
              <Archive size={48} className="empty-icon" />
              <p>Geçmiş aktivite yok</p>
            </div>
          </div>
        )}

        {activeTab === 'havuz' && (
          <div className="tab-view">
             <div className="empty-state">
              <Lightbulb size={48} className="empty-icon" />
              <p>Birlikte yapılacak fikirler ekleyin</p>
            </div>
            <button className="btn-action" onClick={() => toast.success('Fikir ekleme açılıyor...')}>
              <Plus size={18} /> Fikir Ekle
            </button>
          </div>
        )}
      </div>
    </AnimatedPage>
  );
}
