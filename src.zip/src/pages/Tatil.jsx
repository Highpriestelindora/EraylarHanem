import React from 'react';
import { Map, Plus } from 'lucide-react';
import AnimatedPage from '../components/AnimatedPage';
import toast from 'react-hot-toast';
import './GenericModule.css';

export default function Tatil() {
  return (
    <AnimatedPage className="generic-container tatil-theme">
      <div className="generic-header">
        <h2>Eraylar Tatil</h2>
        <p>Seyahat planları ve rotalar</p>
      </div>

      <div className="generic-content">
        <div className="empty-state">
          <Map size={48} className="empty-icon" />
          <p>Planlanmış bir tatil yok</p>
        </div>
        <button className="btn-action" onClick={() => toast.success('Yeni tatil planı ekleniyor...')}>
          <Plus size={18} /> Yeni Tatil Planı
        </button>
      </div>
    </AnimatedPage>
  );
}
